This project includes a font from Google Fonts.
It's up to you how you'd like to implement it.

https://fonts.google.com/specimen/Source+Serif+Pro
